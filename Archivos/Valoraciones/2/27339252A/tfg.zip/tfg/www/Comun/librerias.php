<!-- Librerias para los estilos -->

<?php
$server_name = 'http://' . $_SERVER['SERVER_NAME'] . '/tfg/';
?>

<link rel="stylesheet" type="text/css" href="<?= $server_name; ?>static/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?= $server_name; ?>static/css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="<?= $server_name; ?>static/css/jquery-ui.min.css">
<link rel="stylesheet" type="text/css" href="<?= $server_name; ?>static/css/jquery-ui.theme.min.css">
<link href="<?= $server_name; ?>static/css/style.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="<?= $server_name; ?>static/js/jquery-1.12.3.min.js"></script>
<script type="text/javascript" src="<?= $server_name; ?>static/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?= $server_name; ?>static/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">