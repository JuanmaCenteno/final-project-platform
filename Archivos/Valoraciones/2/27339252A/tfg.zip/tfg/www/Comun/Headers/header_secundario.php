<nav class="navbar-personal" role="navigation">
    <div class="hueco"></div>
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?= $server_name; ?>www/Comun/Headers/redireccion.php">Plataforma de subida de
                Proyectos JM Centeno</a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar" style="color: white;"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">

            <ul class="nav navbar-nav navbar-right">
                <li><a type=button href="#" onclick="history.back(-1)">Volver</a></li>
                <li><a href="<?= $server_name; ?>www/Comun/ctrlAcceso.php?action=out">Cerrar sesión</a></li>
            </ul>

        </div>
    </div>
    <div class="hueco"></div>
</nav>